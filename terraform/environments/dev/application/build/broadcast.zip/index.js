const ENDPOINT = process.env.BROADCAST_ENDPOINT;
// DynamoDB Streams hand back attribute-typed values ({"S": "..."}), not plain JSON
const plain = (image) => Object.fromEntries(Object.entries(image).map(([k, v]) => [
    k,
    "S" in v ? v.S : "N" in v ? Number(v.N) : v,
]));
export const handler = async (event) => {
    const vessels = event.Records
        .filter((r) => r.eventName !== "REMOVE" && r.dynamodb.NewImage)
        .map((r) => plain(r.dynamodb.NewImage));
    if (vessels.length === 0)
        return;
    try {
        const res = await fetch(ENDPOINT, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ vessels }),
        });
        console.log(`posted ${vessels.length} vessels → ${res.status}`);
    }
    catch (err) {
        console.error("broadcast failed:", err);
    }
};
