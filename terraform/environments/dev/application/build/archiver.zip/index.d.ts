type KinesisEvent = {
    Records: {
        kinesis: {
            data: string;
            sequenceNumber: string;
            partitionKey: string;
            approximateArrivalTimestamp: number;
        };
    }[];
};
export declare const handler: (event: KinesisEvent) => Promise<{
    batchItemFailures: {
        itemIdentifier: string;
    }[];
}>;
export {};
//# sourceMappingURL=index.d.ts.map